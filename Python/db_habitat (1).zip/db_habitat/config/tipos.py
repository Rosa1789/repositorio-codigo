from enum import IntEnum, Enum

class Estado(IntEnum):
    EN_PROGRESO = 1
    APROBADO = 2
    CANCELADO = 3
    RECHAZADO = 4
    PENDIENTE = 5
    EN_ESPERA = 6
    COMPLETADO = 7
    FALLIDO = 8
    COMPLETADO_CON_ERRORES = 9

class BaseDatos(Enum):
    PRODAFP = "prodafp"
    IQPROD = "iqprod"
    PRODWEYR = "prodweyr"
    EXPL = "expl"
    HABITAT = "habitat"
    CERTRTP = "certrtp"
    IQDESA = "iqdesa"
    OFFLINE = "offline"