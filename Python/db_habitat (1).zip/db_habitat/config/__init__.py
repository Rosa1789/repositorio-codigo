import logging
import os
from .tipos import Estado, BaseDatos

CONFIG = {
    "USERNAME":os.environ["USERNAME"],
    "USERNAME_PRODWEYR": os.environ["USERNAME_PRODWEYR"],
    "USERNAME_IQPROD":os.environ.get("USERNAME_IQPROD") or os.environ["USERNAME"],
    "PASSWORD":os.environ.get("PASSWORD"),
    "PASSWORD_PRODAFP": os.environ.get("PASSWORD_PRODAFP"),
    "PASSWORD_IQPROD": os.environ.get("PASSWORD_IQPROD"),
    "PASSWORD_HABITAT": os.environ.get("PASSWORD_HABITAT"),
    "PASSWORD_EXPL": os.environ.get("PASSWORD_EXPL"),
    "PASSWORD_PRODWEYR": os.environ.get("PASSWORD_PRODWEYR"),
    "DSN_IQPROD": 'iqprod16' if os.environ.get("DSN_IQPROD") is None else os.environ.get("DSN_IQPROD"),
    "PRODAFP_STRING": "prodafpvip1.afphabitat.cl:1522/?service_name=prodafp",
    "EXPL_STRING": "explvip1.afphabitat.cl:1521/?service_name=expl10g",
    "HABITAT_STRING": "habitatvip1.afphabitat.cl:1521/?service_name=habitat",
    "PRODWEYR_STRING": "lnxdbplan12c.afphabitat.cl:1521/?service_name=prodweyr",
    "IQPROD_STRING": "lnxdbplan12c.afphabitat.cl:1521/?service_name=prodweyr",
    "ORACLE_STRING": "oracle+cx_oracle",
    "SYBASE_STRING": "sybase+pyodbc",
    "TABLA_AUDITORIA": "EXP_ERO.AUDITORIA"
}

logging.basicConfig(
    level=logging.DEBUG,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
